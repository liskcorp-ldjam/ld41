Game is meant to be called Space Maniac, but projects a bit broken.

Everything in the game can be used for free. 
Code is a mess.
Does not follow Ludum Dare theme sadly ( too difficult for us in such a short amount of time)
many bugs but not enough time to fix - will fix soon

Have fun with this...something
